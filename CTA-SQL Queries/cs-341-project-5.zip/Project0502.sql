-- Project0502.sql
-- 2.	Retrieve the number of unique bikeIDs
Select Count(Distinct BikeID) As NumBikes
From Trips