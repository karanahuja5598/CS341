-- Project0501.sql
-- 1.	Retrieve the number of trips recorded in the database.
Select Count(TripID) AS NumTrips
From Trips
